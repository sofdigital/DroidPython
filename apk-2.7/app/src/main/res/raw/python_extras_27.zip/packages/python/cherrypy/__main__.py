import cherrypy.daemon

if __name__ == '__main__':
    cherrypy.daemon.run()
